package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.Collections;
import java.util.ArrayList;

public class recommendationsListActivity extends AppCompatActivity {
    String genre_id;
    ListView myList;
    ProgressBar progressBar;
    ArrayList<String> titleList;
    ArrayAdapter<String> adapter;
    String title;
    public String malId;
    public String url;
    public String imageURL;
    public String synopsis;
    public String episodes;
    public String score;
    public String start_date;
    public String end_date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommendations_list);
        myList = findViewById(R.id.list);
        progressBar = findViewById(R.id.progress_bar);

        Intent intent = getIntent();
        genre_id = intent.getStringExtra("genre_id");
        progressBar.setVisibility(View.VISIBLE);

        String urlStr = "https://api.jikan.moe/v3/genre/anime/" + genre_id + "/1";
        recommendationsBackgroundTasks tasks = new recommendationsBackgroundTasks(this,urlStr,myList);
        tasks.execute();
    }

    public void viewList(final ArrayList<String> arrayList){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.GONE);
            }
        },600);
        titleList = new ArrayList<>();
        for(int i=0; i<arrayList.size();i+=8){
            titleList.add(arrayList.get(i));
        }

        Collections.sort(titleList);
        adapter = new ArrayAdapter<String>(this,R.layout.extra_view,titleList);
        myList.setAdapter(adapter);
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent (recommendationsListActivity.this,searchResultsListActivity.class);
                Bundle bundle = new Bundle();
                title = titleList.get(position);
                bundle.putString("title",title);
                for(int i=0;i<arrayList.size();i++){
                    if(titleList.get(position).equals(arrayList.get(i))){
                    malId = arrayList.get(i+1);
                    bundle.putString("malID",malId);
                    url = arrayList.get(i+2);
                    bundle.putString("url",url);
                    imageURL = arrayList.get(i+3);
                    bundle.putString("imageURL",imageURL);
                    synopsis = arrayList.get(i+4);
                    bundle.putString("synopsis",synopsis);
                    episodes = arrayList.get(i+5);
                    bundle.putString("episodes",episodes);
                    score = arrayList.get(i+6);
                    bundle.putString("score",score);
                    start_date = arrayList.get(i+7);
                    bundle.putString("start_date",start_date);
                    Log.d("jsonStr",malId);
                    break;
                    }
                }
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

    }
}
