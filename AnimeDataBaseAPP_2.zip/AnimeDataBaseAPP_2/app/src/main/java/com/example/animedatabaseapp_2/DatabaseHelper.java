package com.example.animedatabaseapp_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String Completed_Table= "completed";
    public static final String Database_Name = "list_2.db";
    public static final String Planning_To_Watch_Table = "planning_to_watch";
    public static final String Currently_Watching_Table = "currently_watching";
    public static final String Table_Name = "list_data_info";
    public static final String Anime_Name = "";
    public static final String ID = "";

    public DatabaseHelper(Context context) {
        super(context, Database_Name, null, 22);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CreateTable = "CREATE TABLE " + Table_Name + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "Anime_Name TEXT)";
        db.execSQL(CreateTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if(oldVersion < 22){
            db.execSQL("CREATE TABLE " + Currently_Watching_Table + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "Anime_Name TEXT, Synopsis TEXT, Score TEXT, imageURL TEXT, Episodes TEXT, URL TEXT)");

            //, Synopsis TEXT, Score TEXT, imageURL TEXT, Episodes TEXT, URL TEXT
        }
    }

    public boolean addData(String Anime_Name, String Synopsis, String Score, String imageURL, String Episodes, String URL){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Anime_Name", Anime_Name);
        values.put("Synopsis", Synopsis);
        values.put("Score", Score);
        values.put("imageURL", imageURL);
        values.put("Episodes",Episodes);
        values.put("URL", URL);
        long result = db.insert(Table_Name,null,values);

        if(result == -1){
            String results = "It didn't work";
            Log.d("jsonStr",results);
            return false;
        }
        return true;
    }

    public boolean addCurrentlyWatchingData(String Anime_Name, String Synopsis, String Score, String imageURL, String Episodes, String URL){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Anime_Name", Anime_Name);
        values.put("Synopsis", Synopsis);
        values.put("Score", Score);
        values.put("imageURL", imageURL);
        values.put("Episodes",Episodes);
        values.put("URL", URL);
        long result = db.insert(Currently_Watching_Table,null,values);

        if(result == -1){
            String results = "It didn't work";
            Log.d("jsonStr",results);
            return false;
        }
        return true;
    }

    public boolean addPlanningToWatchData(String Anime_Name, String Synopsis, String Score, String imageURL, String Episodes, String URL){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Anime_Name", Anime_Name);
        values.put("Synopsis", Synopsis);
        values.put("Score", Score);
        values.put("imageURL", imageURL);
        values.put("Episodes",Episodes);
        values.put("URL", URL);
        long result = db.insert(Planning_To_Watch_Table,null,values);
        if(result == -1){
            String results = "It didn't work";
            Log.d("jsonStr",results);
            return false;
        }
        return true;
    }

    public boolean addCompletedData(String Anime_Name, String Synopsis, String Score, String imageURL, String Episodes, String URL){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Anime_Name", Anime_Name);
        values.put("Synopsis", Synopsis);
        values.put("Score", Score);
        values.put("imageURL", imageURL);
        values.put("Episodes",Episodes);
        values.put("URL", URL);
        long result = db.insert(Completed_Table,null,values);

        if(result == -1){
            String results = "It didn't work";
            Log.d("jsonStr",results);
            return false;
        }
        return true;
    }



    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + Table_Name, null);
        return data;
    }

    public Cursor viewCurrentlyWatching(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + Currently_Watching_Table, null);
        return data;
    }

    public Cursor viewCompletedList(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + Completed_Table, null);
        return data;
    }

    public Cursor viewPlanningToWatchdList(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + Planning_To_Watch_Table, null);
        return data;
    }

    public int delete(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Table_Name, "Anime_Name=?", new String[]{name});

    }

    public int deleteCurrentlyWatching(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Currently_Watching_Table, "Anime_Name=?", new String[]{name});

    }

    public int deleteCompleted(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Completed_Table, "Anime_Name=?", new String[]{name});

    }

    public int deletePlanningToWatch(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Planning_To_Watch_Table, "Anime_Name=?", new String[]{name});

    }
}
