package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class updateListActivity extends AppCompatActivity {
    Button plan_to_watch;
    Button currently_watching;
    Button completed;
    DatabaseHelper helper;
    int flag;
    String title;
    String synopsis;
    String score;
    String imageURL;
    String episodes;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_list);

        plan_to_watch = (Button) findViewById(R.id.Plan_to_watch);
        currently_watching = (Button) findViewById(R.id.currently_watching);
        completed = (Button) findViewById(R.id.completed);

        helper = new DatabaseHelper(this);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        synopsis = intent.getStringExtra("synopsis");
        score = intent.getStringExtra("score");
        imageURL = intent.getStringExtra("imageURL");
        episodes = intent.getStringExtra("episodes");
        url = intent.getStringExtra("url");


        plan_to_watch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedRows = helper.delete(title);
                Integer deletedCurrentlyWatchingRows = helper.deleteCurrentlyWatching(title);
                Integer deletedCompetedRows = helper.deleteCompleted(title);

                helper.addPlanningToWatchData(title,synopsis,score,imageURL,episodes,url);
                helper.addData(title,synopsis,score,imageURL,episodes,url);
                Intent intent1 = new Intent(updateListActivity.this,listActivity.class);
                startActivity(intent1);
            }
        });

        currently_watching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.addCurrentlyWatchingData(title,synopsis,score,imageURL,episodes,url);
                Integer deletedRows = helper.delete(title);
                Integer deletedPlanningToWatchRows = helper.deletePlanningToWatch(title);
                Integer deletedCompetedRows = helper.deleteCompleted(title);
               helper.addData(title,synopsis,score,imageURL,episodes,url);
                Intent intent1 = new Intent(updateListActivity.this,listActivity.class);
                startActivity(intent1);
            }
        });

        completed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedRows = helper.delete(title);
                Integer deletedPlanningToWatchRows = helper.deletePlanningToWatch(title);
                Integer deletedCurrentlyWatchingRows = helper.deleteCurrentlyWatching(title);

                helper.addCompletedData(title,synopsis,score,imageURL,episodes,url);
                helper.addData(title,synopsis,score,imageURL,episodes,url);
                Intent intent1 = new Intent(updateListActivity.this,listActivity.class);
                startActivity(intent1);
            }
        });
    }
}
