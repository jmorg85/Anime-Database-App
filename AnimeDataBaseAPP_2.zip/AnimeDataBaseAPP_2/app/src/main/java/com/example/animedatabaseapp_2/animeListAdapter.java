package com.example.animedatabaseapp_2;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class animeListAdapter extends ArrayAdapter<String> {
    public ArrayList<String> list;
    public Context context;
    public String title;
    public String ImageURL;
    public animeListAdapter(Context context, int resource, ArrayList<String> objects) {
        super(context, resource, objects);
        list = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.custon_list_layout, parent, false);
        ImageView myImageView = (ImageView) rowView.findViewById(R.id.image);
        Log.d("title", "Pos: " + position);
        title = list.get(position*2);
        ImageURL = list.get((position*2)+1);
        TextView myTextView = (TextView) rowView.findViewById(R.id.text);
        Picasso.with(context).load(ImageURL).into(myImageView);
        myTextView.setText(ImageURL);
        return rowView;
    }
}
