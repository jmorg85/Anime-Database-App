package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class favoritesActivity extends AppCompatActivity {
    TextView text;
    ListView listView;
    ArrayList<String> myFavoritesList;
    ArrayAdapter<String> adapter;
    FavoritesDatabaseHelper fav;
    Button home;
    Cursor results;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        listView = findViewById(R.id.listView);

        myFavoritesList = new ArrayList<>();
        fav = new FavoritesDatabaseHelper(this);
        results = fav.getListContents();
        home = (Button) findViewById(R.id.home);

        if(results.getCount() == 0){
            Toast.makeText(this, "There is nothing here.", Toast.LENGTH_LONG).show();
        }

        String line = "";
        int i = 1;
        while(results.moveToNext()){
            line = results.getString(2);
            myFavoritesList.add(line);
            i++;
        }
        adapter = new ArrayAdapter<>(this,R.layout.extra_view,myFavoritesList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String placement = myFavoritesList.get(position);
                Toast.makeText(favoritesActivity.this, placement,Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(favoritesActivity.this, DeleteFavoritesActivity.class);
                intent.putExtra("placement", placement);
                startActivity(intent);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(favoritesActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
