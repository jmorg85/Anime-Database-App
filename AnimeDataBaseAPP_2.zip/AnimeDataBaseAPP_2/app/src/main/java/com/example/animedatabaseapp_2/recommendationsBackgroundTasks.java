package com.example.animedatabaseapp_2;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class recommendationsBackgroundTasks extends AsyncTask<Void, Void, String> implements Serializable {
    public recommendationsListActivity myRecommendations;
    public ListView myListView;
    public String urlStr; //url to connect to
    public ArrayList<String> myArrayList = new ArrayList<>(); //parsed data
    public ArrayAdapter<String> myAdapter;
    public String malId;
    public String url;
    public String imageURL;
    public String title;
    public String synopsis;
    public String episodes;
    public String score;
    public String start_date;
    public String end_date;

    recommendationsBackgroundTasks(recommendationsListActivity activity_in, String urlStr_in, ListView listView_in){
        myRecommendations = activity_in;
        urlStr = urlStr_in;
        myListView = listView_in;
    }
    @Override
    protected String doInBackground(Void... voids) {
        String jsonStr = "";
        URL myUrl = null;
        try {
            myUrl = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection)
                    myUrl.openConnection();
            connection.setRequestMethod("GET");
            BufferedReader in;
            in = new BufferedReader(new
                    InputStreamReader(connection.getInputStream()));
            StringBuffer sb = new StringBuffer("");
            String line = "";
            while ((line = (String) in.readLine()) != null)
            {
                sb.append(line);
            }
            in.close();
            jsonStr = sb.toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return jsonStr;
    }

    @Override
    protected void onPostExecute(String jsonStr){
        try {
            JSONObject myObject = new JSONObject(jsonStr);
            JSONArray myArray = myObject.getJSONArray("anime");
            for(int i=0; i<myArray.length();i++){
                JSONObject obj = myArray.getJSONObject(i);
                title = obj.getString("title");
                myArrayList.add(title);
                malId = obj.getString("mal_id");
                myArrayList.add(malId);
                url = obj.getString("url");
                myArrayList.add(url);
                imageURL = obj.getString("image_url");
                myArrayList.add(imageURL);
                synopsis = obj.getString("synopsis");
                myArrayList.add(synopsis);
                episodes = obj.getString("episodes");
                myArrayList.add(episodes);
                score = obj.getString("score");
                myArrayList.add(score);
                start_date = obj.getString("airing_start");
                myArrayList.add(start_date);
            }
            myRecommendations.viewList(myArrayList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
