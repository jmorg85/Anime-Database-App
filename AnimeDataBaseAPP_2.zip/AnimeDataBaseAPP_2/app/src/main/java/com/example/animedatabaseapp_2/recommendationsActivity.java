package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class recommendationsActivity extends AppCompatActivity {
    Button Action;
    Button Romance;
    Button School;
    Button Sci_Fi;
    Button Mystery;
    Button Mecha;
    Button Shoujo;
    Button Space;
    Button Sports;
    Button Vampire;
    Button Slice_of_life;
    Button Supernatural;
    Button Military;
    Button Police;
    Button Psychological;
    String genre_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommendations);
        Action= findViewById(R.id.Action);
        Romance = findViewById(R.id.Romance);
        School = findViewById(R.id.School);
        Sci_Fi = findViewById(R.id.Sci_Fi);
        Mystery = findViewById(R.id.Mystery);
        Mecha = findViewById(R.id.Mecha);
        Shoujo = findViewById(R.id.Shoujo);
        Space = findViewById(R.id.Space);
        Sports = findViewById(R.id.Sports);
        Vampire = findViewById(R.id.Vampire);
        Slice_of_life = findViewById(R.id.Slice_Of_Life);
        Supernatural = findViewById(R.id.Supernatural);
        Military = findViewById(R.id.Military);
        Police = findViewById(R.id.Police);
        Psychological = findViewById(R.id.Psychological);

        Action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "1";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Romance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "22";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        School.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "23";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Sci_Fi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "24";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Mystery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "7";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Mecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "18";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Shoujo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "25";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Space.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "29";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Sports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "30";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Vampire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "32";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Slice_of_life.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "36";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Supernatural.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "37";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Military.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "38";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Police.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "39";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

        Psychological.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                genre_id = "40";
                Intent intent = new Intent(recommendationsActivity.this, recommendationsListActivity.class);
                intent.putExtra("genre_id",genre_id);
                startActivity(intent);
            }
        });

    }
}
