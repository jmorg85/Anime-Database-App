package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Collections;

import java.util.ArrayList;

public class listActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    ListView list;
    TextView text;
    Button home;
    Spinner spin;
    ArrayAdapter<String> adapter;
    ArrayAdapter<CharSequence> spinnerAdapter;
    ArrayList<String> titles;
    DatabaseHelper db;
    Cursor result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_list);
        list = (ListView) findViewById(R.id.list);
        text = (TextView) findViewById(R.id.text);
        home = (Button) findViewById(R.id.home);
        spin = (Spinner) findViewById(R.id.Spinner);


        titles = new ArrayList<>();
        spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.lists, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(spinnerAdapter);

        spin.setOnItemSelectedListener(this);
        db = new DatabaseHelper(this);
        result = db.getListContents();
        if(result.getCount() == 0){
            Toast.makeText(this, "There is nothing here.", Toast.LENGTH_LONG).show();
        }
        String line ="";
        StringBuffer buffer = new StringBuffer();
        while(result.moveToNext()){
            line = result.getString(1);
            titles.add(line);
        }

        Collections.sort(titles);
        adapter = new ArrayAdapter<>(this,R.layout.extra_view, titles);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String placement = titles.get(position);
                Intent intent = new Intent(listActivity.this, DeleteActivity.class);
                intent.putExtra("placement", placement);
                startActivity(intent);

            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(listActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        if(parent.getItemAtPosition(position).equals("All")){

        }
        if(parent.getItemAtPosition(position).equals("Currently watching")){
            Intent intent = new Intent(this,otherList.class);
            String num = "0";
            intent.putExtra("num",num);
            startActivity(intent);
        }
        if(parent.getItemAtPosition(position).equals("Plan to Watch")){
            Intent intent = new Intent(this,otherList.class);
            String num = "1";
            intent.putExtra("num",num);
            startActivity(intent);
        }
        if(parent.getItemAtPosition(position).equals("Completed")){
            Intent intent = new Intent(this,otherList.class);
            String num = "2";
            intent.putExtra("num",num);
            startActivity(intent);
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
