package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String urlStr;
    Button button;
    Button search;
    Button favorites;
    Button list;
    Button coming_soon;
    String word;
    DatabaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search = (Button) findViewById(R.id.search);
        favorites = (Button) findViewById(R.id.favorites);
        list = (Button) findViewById(R.id.list);
        coming_soon = (Button) findViewById(R.id.coming_soon);
        myDB = new DatabaseHelper(this);

    }

    public void favoritesSelected(View v){
        Intent intent = new Intent(this, favoritesActivity.class);
        startActivity(intent);
    }

    public void searchSelected(View v){
        Intent intent = new Intent(this, searchActivity.class);
        startActivity(intent);
    }

    public void listSelected(View v){
        Intent intent = new Intent(this, listActivity.class);
        startActivity(intent);
    }

    public void recommendationsSelected(View v){
        Intent intent = new Intent(this, recommendationsActivity.class);
        startActivity(intent);
    }


}
