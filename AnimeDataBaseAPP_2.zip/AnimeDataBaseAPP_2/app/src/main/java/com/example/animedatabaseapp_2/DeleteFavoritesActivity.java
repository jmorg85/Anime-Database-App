package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DeleteFavoritesActivity extends AppCompatActivity {
    TextView text;
    FavoritesDatabaseHelper fav;
    String placement;
    Button delete;
    Button viewInformation;
    String Anime_Name;
    String Synopsis;
    String Score;
    String imageURL;
    String Episodes;
    String url;
    Cursor results;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_favorites);

        text = (TextView) findViewById(R.id.text);
        delete = (Button) findViewById(R.id.delete);
        viewInformation = (Button) findViewById(R.id.viewInfo);

        fav = new FavoritesDatabaseHelper(this);
        results = fav.getListContents();

        Intent intent = getIntent();

        placement = intent.getStringExtra("placement");

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedRows = fav.delete(placement);
                Intent finish = new Intent(DeleteFavoritesActivity.this, favoritesActivity.class);
                startActivity(finish);

            }
        });

        viewInformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                while (results.moveToNext()){
                    Anime_Name = results.getString(2);
                    Synopsis = results.getString(3);
                    Score = results.getString(4);
                    imageURL = results.getString(5);
                    Episodes = results.getString(6);
                    url = results.getString(7);

                    if(placement.equals(Anime_Name)){
                        Intent next = new Intent(DeleteFavoritesActivity.this, searchResultsListActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("title",Anime_Name);
                        bundle.putString("synopsis", Synopsis);
                        bundle.putString("score",Score);
                        bundle.putString("imageURL",imageURL);
                        bundle.putString("episodes", Episodes);
                        bundle.putString("url", url);
                        next.putExtras(bundle);
                        startActivity(next);

                    }
                }
            }
        });
    }
}
