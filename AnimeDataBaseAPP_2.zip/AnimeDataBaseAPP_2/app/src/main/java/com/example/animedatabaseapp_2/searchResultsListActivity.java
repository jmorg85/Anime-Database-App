package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.os.TestLooperManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class searchResultsListActivity extends AppCompatActivity {
ArrayList<String> list;
TextView text;
TextView synopsis_text_view;
TextView score_text_view;
TextView episode_count;
TextView malLink;
ImageView image;
Button addToList;
Button addToFavorites;
Button home;
Button share;
DatabaseHelper myDB;
FavoritesDatabaseHelper fav;

listActivity myListActivity;

String title;
String synopsis;
String score;
String imageURL;
String url;
String episodes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results_list);

        Intent intent=getIntent();
        text = (TextView) findViewById(R.id.name);
        synopsis_text_view = (TextView) findViewById(R.id.synopsis);
        score_text_view = (TextView) findViewById(R.id.score);
        image = (ImageView) findViewById(R.id.image);
        episode_count = (TextView) findViewById(R.id.episode_count);
        malLink = (TextView) findViewById(R.id.malLink);
        addToList = (Button) findViewById(R.id.addToList);
        addToFavorites = (Button) findViewById(R.id.favorites);
        home = (Button) findViewById(R.id.home);
        share = findViewById(R.id.share);

        myDB = new DatabaseHelper(this);
        fav = new FavoritesDatabaseHelper(this);

        title = intent.getStringExtra("title");
        synopsis = intent.getStringExtra("synopsis");
        score = intent.getStringExtra("score");
        imageURL = intent.getStringExtra("imageURL");
        episodes = intent.getStringExtra("episodes");
        url = intent.getStringExtra("url");

        text.setText(title);
        synopsis_text_view.setText(synopsis);
        score_text_view.setText("Score:\n"+score);
        Picasso.with(this).load(imageURL).into(image);
        episode_count.setText("Episode Count:\n" + episodes);
        malLink.setText("For the full synopsis and more please visit the link:\n" + url);

        addToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("title", title);
                Intent next = new Intent(searchResultsListActivity.this, What_list_are_you_adding_it_to.class);
                Bundle bundle = new Bundle();
                bundle.putString("title",title);
                bundle.putString("synopsis",synopsis);
                bundle.putString("score",score);
                bundle.putString("imageURL",imageURL);
                bundle.putString("episodes",episodes);
                bundle.putString("url",url);
                next.putExtras(bundle);
                startActivity(next);
            }
        });

        addToFavorites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(searchResultsListActivity.this,"It's been added",Toast.LENGTH_SHORT).show();
                fav.addData(title,synopsis,score,imageURL,episodes,url);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(searchResultsListActivity.this, MainActivity.class);
                startActivity(home);
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                String message = "Hey, check out this anime I found, who knows you might like it. It's called " + title +  ". Click the " +
                        "link for info on it\n" + url;
                share.putExtra(Intent.EXTRA_TEXT, message);
                startActivity(Intent.createChooser(share, "Share using"));
            }
        });

    }



}
