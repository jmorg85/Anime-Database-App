package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class otherList extends AppCompatActivity {
    ListView list;
    TextView text;
    Button home;
    ArrayAdapter<String> adapter;
    String num;
    String line = "";
    ArrayAdapter<CharSequence> spinnerAdapter;
    ArrayList<String> titles;
    DatabaseHelper db;
    Cursor result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_list);

        list = (ListView) findViewById(R.id.list);
        text = (TextView) findViewById(R.id.text);
        home = (Button) findViewById(R.id.home);

        Intent intent = getIntent();
        num = intent.getStringExtra("num");

        titles = new ArrayList<>();

        db = new DatabaseHelper(this);

            if(num.equals("0")){
                result = db.viewCurrentlyWatching();
                if (result.getCount() == 0) {
                    Toast.makeText(this, "There is nothing here.", Toast.LENGTH_LONG).show();
                }

                while (result.moveToNext()) {
                    line = result.getString(1);
                    titles.add(line);
                }

                Collections.sort(titles);
                adapter = new ArrayAdapter<>(this, R.layout.extra_view, titles);
                list.setAdapter(adapter);
            }
            if(num.equals("1")) {
                result = db.viewPlanningToWatchdList();
                if (result.getCount() == 0) {
                    Toast.makeText(this, "There is nothing here.", Toast.LENGTH_LONG).show();
                }

                while (result.moveToNext()) {
                    line = result.getString(1);
                    titles.add(line);
                }

                Collections.sort(titles);
                adapter = new ArrayAdapter<>(this, R.layout.extra_view, titles);
                list.setAdapter(adapter);
            }
            if(num.equals("2")){
                result = db.viewCompletedList();
                if (result.getCount() == 0) {
                    Toast.makeText(this, "There is nothing here.", Toast.LENGTH_LONG).show();
                }

                while (result.moveToNext()) {
                    line = result.getString(1);
                    titles.add(line);
                }

                Collections.sort(titles);
                adapter = new ArrayAdapter<>(this, R.layout.extra_view, titles);
                list.setAdapter(adapter);
            }


            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String placement = titles.get(position);
                    Intent intent = new Intent(otherList.this, DeleteActivity.class);
                    intent.putExtra("placement", placement);
                    startActivity(intent);

                }
            });

            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(otherList.this, MainActivity.class);
                    startActivity(intent);
                }
            });

    }
}
