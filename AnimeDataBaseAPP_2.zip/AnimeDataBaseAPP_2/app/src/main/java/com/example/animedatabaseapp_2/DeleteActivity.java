package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class DeleteActivity extends AppCompatActivity {
    TextView text;
    EditText name;
    Button delete;
    Button viewInformation;
    Button update;
    String Anime_Name;
    String Synopsis;
    String Score;
    String imageURL;
    String Episodes;
    String url;
    String placement;
    DatabaseHelper db;
    Cursor results;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        text = (TextView) findViewById(R.id.text);
        delete = (Button) findViewById(R.id.delete);
        update = (Button) findViewById(R.id.update);
        viewInformation = (Button) findViewById(R.id.viewInfo);
        db = new DatabaseHelper(this);
        results = db.getListContents();
        Intent intent = getIntent();

        placement = intent.getStringExtra("placement");

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Integer deletedRows = db.delete(placement);
            Integer completeDelete = db.deleteCompleted(placement);
            Integer planToWatchDelete = db.deletePlanningToWatch(placement);
            Integer currentlyWatchingDelete = db.deleteCurrentlyWatching(placement);
            Intent finish = new Intent(DeleteActivity.this, listActivity.class);
            startActivity(finish);

            }
        });
        viewInformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                while (results.moveToNext()){
                    Anime_Name = results.getString(1);
                    Synopsis = results.getString(2);
                    Score = results.getString(3);
                    imageURL = results.getString(4);
                    Episodes = results.getString(5);
                    url = results.getString(6);

                    if(placement.equals(Anime_Name)){
                        Intent next = new Intent(DeleteActivity.this, searchResultsListActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("title",Anime_Name);
                        bundle.putString("synopsis", Synopsis);
                        bundle.putString("score",Score);
                        bundle.putString("imageURL",imageURL);
                        bundle.putString("episodes", Episodes);
                        bundle.putString("url", url);
                        next.putExtras(bundle);
                        startActivity(next);

                    }
                }
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent1 = new Intent(DeleteActivity.this,updateListActivity.class);
                while(results.moveToNext()){
                    Anime_Name = results.getString(1);
                    Synopsis = results.getString(2);
                    Score = results.getString(3);
                    imageURL = results.getString(4);
                    Episodes = results.getString(5);
                    url = results.getString(6);
                }

                if(placement.equals(Anime_Name)){
                    Bundle bundle = new Bundle();
                    bundle.putString("title",Anime_Name);
                    bundle.putString("synopsis", Synopsis);
                    bundle.putString("score",Score);
                    bundle.putString("imageURL",imageURL);
                    bundle.putString("episodes", Episodes);
                    bundle.putString("url", url);
                    intent1.putExtras(bundle);
                    startActivity(intent1);

                }
            startActivity(intent1);
            }
        });
    }
}
