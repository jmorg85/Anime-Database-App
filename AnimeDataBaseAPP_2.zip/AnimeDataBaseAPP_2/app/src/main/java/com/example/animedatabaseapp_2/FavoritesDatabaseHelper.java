package com.example.animedatabaseapp_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class FavoritesDatabaseHelper extends SQLiteOpenHelper {
    public static final String Database_Name = "favoritesList.db";
    public static final String Table_Name = "favorites_list_data";
    public static final String Anime_Name = "";
    public static final String ranking = "";
    public FavoritesDatabaseHelper(Context context) {
        super(context, Database_Name, null, 6);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CreateTable = "CREATE TABLE " + Table_Name + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "Ranking TEXT, Anime_Name TEXT)";
        db.execSQL(CreateTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public boolean addData(String Anime_Name, String Synopsis, String Score, String imageURL, String Episodes, String URL){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Anime_Name", Anime_Name);
        values.put("Synopsis", Synopsis);
        values.put("Score", Score);
        values.put("imageURL", imageURL);
        values.put("Episodes", Episodes);
        values.put("URL", URL);

        long result = db.insert(Table_Name,null,values);

        if(result == -1){
            return false;
        }
        return true;
    }

    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + Table_Name, null);
        return data;
    }

    public int delete(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Table_Name, "Anime_Name=?", new String[]{name});

    }
}
