package com.example.animedatabaseapp_2;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class searchActivity extends AppCompatActivity implements Serializable {
    EditText search_bar;
    Button search_button;
    ProgressBar progressBar;
    String query;
    ListView myListView;
    String title;
    ArrayList<String> titleList;
    ArrayList<String> listForAdapter;
    public String malId;
    public String url;
    public String imageURL;
    public String synopsis;
    public String episodes;
    public String score;
    public String start_date;
    public String end_date;
    public String listAdapterTitle;
    public String listAdapterImageURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        search_bar = (EditText) findViewById(R.id.search_bar);
        search_button = (Button) findViewById(R.id.search_button);
        myListView = (ListView) findViewById(R.id.list);
        progressBar = findViewById(R.id.progress_bar);
        progressBar.setVisibility(View.VISIBLE);
    }

    public void searchResults(View v) {
        query = search_bar.getText().toString();
        Log.d("userName", query);
        String urlStr = "https://api.jikan.moe/v3/search/anime?q=" + query;
        Log.d("url", urlStr);
        backgroundTasks tasks = new backgroundTasks(this, urlStr, myListView);
        tasks.execute();
    }

    public void viewList(final ArrayList<String> list) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.GONE);
            }
        },600);
        titleList = new ArrayList<>();
        listForAdapter = new ArrayList<>();
        for(int i=0;i<list.size()/9;i++){

                //It goes title, then imageURL
                listAdapterTitle = list.get((9*i+3));
                listForAdapter.add(listAdapterTitle);
                listAdapterImageURL = list.get(9*i+2);
                listForAdapter.add(listAdapterImageURL);
        }
        for (int i = 3; i < list.size(); i += 9) {
            titleList.add(list.get(i));
        }

        //animeListAdapter adapter = new animeListAdapter(this,R.layout.custon_list_layout,listForAdapter);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(this, R.layout.extra_view, titleList);
        myListView.setAdapter(myAdapter);
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(searchActivity.this, searchResultsListActivity.class);
                Bundle bundle = new Bundle();
                title = titleList.get(position);
                for(int i=0; i<list.size(); i++){
                    if(titleList.get(position).equals(list.get(i))){
                        malId = list.get(i-3);
                        bundle.putString("malId", malId);
                        url = list.get(i-2);
                        bundle.putString("url", url);
                        imageURL = list.get(i-1);
                        bundle.putString("imageURL", imageURL);
                        title = list.get(i);
                        bundle.putString("title", title);
                        synopsis = list.get(i+1);
                        bundle.putString("synopsis", synopsis);
                        episodes = list.get(i+2);
                        bundle.putString("episodes", episodes);
                        score = list.get(i+3);
                        bundle.putString("score", score);
                        start_date = list.get(i+4);
                        bundle.putString("start_date", start_date);
                        end_date = list.get(i+5);
                        bundle.putString("end_date", end_date);

                          break;

                    }

                }
                //Toast.makeText(searchActivity.this, titleList.get(position), Toast.LENGTH_SHORT).show();
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }


}
