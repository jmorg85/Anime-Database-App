package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class What_list_are_you_adding_it_to extends AppCompatActivity {
    Button plan_to_watch;
    Button currently_watching;
    Button completed;
    DatabaseHelper helper;
    int flag;
    String title;
    String synopsis;
    String score;
    String imageURL;
    String episodes;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_what_list_are_you_adding_it_to);
        helper = new DatabaseHelper(this);

        plan_to_watch = (Button) findViewById(R.id.Plan_to_watch);
        currently_watching = (Button) findViewById(R.id.currently_watching);
        completed = (Button) findViewById(R.id.completed);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        synopsis = intent.getStringExtra("synopsis");
        score = intent.getStringExtra("score");
        imageURL = intent.getStringExtra("imageURL");
        episodes = intent.getStringExtra("episodes");
        url = intent.getStringExtra("url");

        plan_to_watch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor Results = helper.getListContents();
                flag = 1;
                    while(Results.moveToNext()){
                        if(title.equals(Results.getString(1))){
                            Log.d("title",Results.getString(1));
                            Toast.makeText(What_list_are_you_adding_it_to.this,"It's already in your list.",Toast.LENGTH_SHORT).show();
                            flag =0;
                        }
                    }
                    if(flag ==1){
                        helper.addPlanningToWatchData(title, synopsis, score, imageURL, episodes, url);
                        helper.addData(title, synopsis, score, imageURL, episodes, url);
                        Toast.makeText(What_list_are_you_adding_it_to.this,"It's been added",Toast.LENGTH_SHORT).show();
                    }

            }
        });

        completed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor Results = helper.getListContents();
                flag = 1;
                while(Results.moveToNext()){
                    if(title.equals(Results.getString(1))){
                        Log.d("title",Results.getString(1));
                        Toast.makeText(What_list_are_you_adding_it_to.this,"It's already in your list.",Toast.LENGTH_SHORT).show();
                        flag =0;
                    }
                }
                if(flag ==1){
                    helper.addCompletedData(title,synopsis,score,imageURL,episodes,url);
                    helper.addData(title, synopsis, score, imageURL, episodes, url);
                    Toast.makeText(What_list_are_you_adding_it_to.this,"It's been added",Toast.LENGTH_SHORT).show();
                }
               /*Toast.makeText(What_list_are_you_adding_it_to.this,"It's been added",Toast.LENGTH_SHORT).show();
                helper.addCompletedData(title,synopsis,score,imageURL,episodes,url);
                helper.addData(title,synopsis,score,imageURL,episodes,url);*/
            }
        });

        currently_watching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor Results = helper.getListContents();
                flag = 1;
                while(Results.moveToNext()){
                    if(title.equals(Results.getString(1))){
                        Log.d("title",Results.getString(1));
                        Toast.makeText(What_list_are_you_adding_it_to.this,"It's already in your list.",Toast.LENGTH_SHORT).show();
                        flag =0;
                    }
                }
                if(flag ==1){
                    helper.addCurrentlyWatchingData(title,synopsis,score,imageURL,episodes,url);
                    helper.addData(title, synopsis, score, imageURL, episodes, url);
                    Toast.makeText(What_list_are_you_adding_it_to.this,"It's been added",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
