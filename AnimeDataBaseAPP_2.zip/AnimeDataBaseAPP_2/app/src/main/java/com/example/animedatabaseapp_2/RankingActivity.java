package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RankingActivity extends AppCompatActivity {
    EditText Rank;
    TextView textView;
    Button submit;
    String rank;
    int newRank;
    String title;
    Cursor results;
    FavoritesDatabaseHelper fav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);
        Rank = (EditText) findViewById(R.id.rank);
        textView = (TextView) findViewById(R.id.text);
        submit = (Button) findViewById(R.id.submit);
        fav = new FavoritesDatabaseHelper(this);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
