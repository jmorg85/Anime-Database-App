package com.example.animedatabaseapp_2;

import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class backgroundTasks extends AsyncTask<Void, Void, String> implements Serializable {
    public searchActivity mySearchActivity;
    public searchResultsListActivity myListActivity;
    public ListView myListView;
    public String urlStr; //url to connect to
    public ArrayList<String> myArrayList = new ArrayList<>(); //parsed data
    public ArrayAdapter<String> myAdapter;
    public String malId;
    public String url;
    public String imageURL;
    public String title;
    public String synopsis;
    public String episodes;
    public String score;
    public String start_date;
    public String end_date;
    backgroundTasks(searchActivity activity_in, String urlStr_in, ListView listView_in)
    {
        mySearchActivity = activity_in;
        urlStr = urlStr_in;
        myListView = listView_in;
    }

    @Override
    protected String doInBackground(Void... params)
    {
        String jsonStr = "";
        URL myUrl = null;
        try {
            myUrl = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection)
                    myUrl.openConnection();
            connection.setRequestMethod("GET");
            BufferedReader in;
            in = new BufferedReader(new
                    InputStreamReader(connection.getInputStream()));
            StringBuffer sb = new StringBuffer("");
            String line = "";
            while ((line = (String) in.readLine()) != null)
            {
                sb.append(line);
            }
            in.close();
            jsonStr = sb.toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }



        return jsonStr;
    }
    @Override
    protected void onPostExecute(String jsonStr){
        try {
            JSONObject myObject = new JSONObject(jsonStr);
            JSONArray myArray = myObject.getJSONArray("results");
            for (int i=0; i<10; i++){
                JSONObject obj = myArray.getJSONObject(i);
                malId = obj.getString("mal_id");
                myArrayList.add(malId);
                url = obj.getString("url");
                myArrayList.add(url);
                imageURL = obj.getString("image_url");
                myArrayList.add(imageURL);
                title = obj.getString("title");
                myArrayList.add(title);
                synopsis = obj.getString("synopsis");
                myArrayList.add(synopsis);
                episodes = obj.getString("episodes");
                myArrayList.add(episodes);
                score = obj.getString("score");
                myArrayList.add(score);
                start_date = obj.getString("start_date");
                myArrayList.add(start_date);
                end_date = obj.getString("end_date");
                myArrayList.add(end_date);
            }
            mySearchActivity.viewList(myArrayList);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
